#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>

struct student_database_encrypted
	{
	  int rollno;
          char name[20];
	  float mark;	
	};

void add_record();
void print_record();
void update_record();
void delete_record();
void sort_record();
void change_password();
void encrypt(struct student_database_encrypted *);
void decrypt(struct student_database_encrypted *);

void isr(int n)
{
  kill(getpid?(),9);
}

main()
{
  FILE *fp;
  int i,n1=0,n,choice;//n1=counter in file if 0 password not choosen if 1 password set
  char s[20]="password",s1[20],pch,pc;
  int sd,newsd,fd;
  char rdbuf[100],wrbuf[100],password_ask[100]="Enter password to login:";
  struct sockaddr_in serv,client;
  /************  SERVER BEGINING ***********/
   //socket creation
   sd=socket(PF_INET,SOCK_STREAM,0);	
   if(sd==-1) 
      {
	     perror("SOCKET\n");
	     return;
	  }
   signal(SIGPIPE,isr);
   //socket initialisation
   serv.sin_family=PF_INET;
   serv.sin_port=htons(2049);
   serv.sin_addr.s_addr=inet_addr("0.0.0.0");
   // connecting socket
   if(bind(sd,(struct sockaddr *)&serv,sizeof(serv))==-1)
         {
		         perror("BIND:\n");	 
		         return;
	     }
   listen(sd,3);
   int len;
   len=sizeof(client);
   printf("SERVER WAITING FOR connection..\n");
   newsd=accept(sd,(struct sockaddr *)&client,&len);// waiting for clients request
   if(newsd==-1)
      {
	     perror("ACCEPT\n");
	     return;
	  }
  printf("CONNECTION SUCCESSFUL\n");
  //goto REAd; // PASSWORD VERIFICATION
  if(fork()) // PARENT WRITING TO CLIENT
  {
	   while(1)
       {
		  bzero(wrbuf,100);
		  write(newsd,wrbuf,99);
	   } 
   }
  else  // CHILD READING FROM CLIENT
   {
	  while(1)
       {
		  bzero(rdbuf,100);
		  if(read(sd,str1,99)<0);
		   {
			  perror("ERROR:");
		      return;   
		   }
		   
		 /* else
            goto CHOICE; // SWITCH CASE CHECKING*/
	   }
	   
	}
  /************ SERVER END ********************/  
  READ:fp=fopen("password1.txt","r+");
  if(fp==NULL)
     { 
       goto CHECK;//if program executed for 1st time file doesnot exist so goto check
     }
  fread(&n1,sizeof(int),1,fp);
  if(n1==0)
    { 
      CHECK:
      printf("Do you want to set password:(y/n)\n");
      scanf("%c",&pc);
      if(pc=='y')//password creation block
      {  
        fp=fopen("password1.txt","w");
      	printf("Enter New password:(max 20 characters)");
      	scanf("%s",s);
        n1=1;
	fwrite(&n1,sizeof(int),1,fp);
      	fwrite(s,sizeof(s),1,fp);
      	rewind(fp);
	printf("password created succesfully\n");
      	goto RETRY;
      }
      else
        goto MENU;
    }
  if(n1==1)// Authentication block
    {
      RETRY:strcpy(wbuf,password_ask);
             bzero(wrbuf,100);
		     write(newsd,wrbuf,99);
		     fread(s,sizeof(s),1,fp);
      if(strcmp(s,s1)==0)
         {
           printf("logged in succesfull\n");
/*main application*/           
       while(1)
  	    {
		MENU:printf("*************************  MENU  *************************\n");
   		printf("Enter choice:\n1.AddRecord\n2.PrintRecord\n3.UpdateRecord\n4.Sort\n5.Delete\n6.Change password\n7.Quit:");
   		scanf("%d",&choice);
        printf("Entered choice is :%d\n\n",choice);
  		 if(choice!=7)
  		 {
    CHOICE:switch(choice)
   			{
	  			case 1:add_record();//function call to add a new record
                 
                 			break;
          			case 2:print_record();//function call to print record data
                 			break;
          			case 3:update_record();//function call to sort
                 			break;
          			case 4:sort_record();//function call to update a record entry
                 			break;
          			case 5:delete_record();//function to delete
                 			break;
				    case 6:change_password();
                            break;
                    case 7: Printf("EXITTING..\n");
                            close(sd);//closing socket
                            close(newsd);//closing socket
                            exit(0);
           			default :printf("ERROR:Invalid choice\n");
        	}
    	}
  	  }
	  printf("Exitting..\n");
/**** main application */
          if(pc=='y')
              fclose(fp);
          return;
        }
      else
          {
            printf("Password mismatch:\n");
            printf("Want to retry:(y/n)\n");
            getchar();
            scanf("%c",&pc);
            if(pc=='y')
                  goto RETRY;
            else 
                    {
                       printf("Process terminated..\n");
                       fclose(fp); 
                       return;
                     }
           }
    }
}
/*****Adding data to database****/
void add_record()
{
   struct student_database_encrypted v;
   FILE *fp;
   printf("enter rollno:\n");
   scanf("%d",&v.rollno);
   printf("enter name:\n");
   scanf("%s",v.name);
   printf("enter marks:\n");
   scanf("%f",&v.mark);
   printf("encrypt caled\n");
   encrypt(&v);
   fp=fopen("student_data_encrypt","a");
   fwrite(&v,sizeof(v),1,fp);
   fclose(fp);
   printf("Record added succesfuly to database\n\n");
}

/*****Printing data from database****/
void print_record()
{
  struct student_database_encrypted v;
  FILE *fp;
  int choice;
  fp=fopen("student_data_encrypt","r");
	if(fp==NULL)
		{
			printf("ERROR: record not found\n");
			return;
		}
  printf("Enter choice:1.print all records  2.print specific record\n");
  scanf("%d",&choice);
  if(choice==1)// Printing whole database
	{	if(fgetc(fp)!=EOF)//File non empty testing
                  {       
                        rewind(fp);
                        printf("NAME\tROLLNO\tMARKS\n");
	        	while(fread(&v,sizeof(v),1,fp))
                              {
                                decrypt(&v);
			        printf("%s\t%d\t%0.2f\n",v.name,v.rollno,v.mark);
                              }
                        printf("\n\n");
	          }  
                else
                        printf("List is empty..\n\n\n");
        }
  else if(choice==2)// Printing single record
	{	
		printf("Enter rollno to print data\n");
                scanf("%d",&choice);
		printf("NAME\tROLLNO\tMARKS\n");
		while(fread(&v,sizeof(v),1,fp))
			{
                                decrypt(&v);    
                      		if(v.rollno==choice)				
					printf("%s\t%d\t%0.2f\n",v.name,v.rollno,v.mark);
			        else
                                        printf("Record not found\n\n");
                        }
	}
  else
	printf("Invalid choice to print\n\n");
  fclose(fp);
}

void update_record()
{
  FILE *fp;
  struct student_database_encrypted v;
  int choice,n;
  fp=fopen("student_data_encrypt","r+");
  if(fp==NULL)
	{
		printf("ERROR: Data base doesnot exist\n\n");
		return;
	}
  printf("Enter rollno of student to updae:\n");
  scanf("%d",&choice);
  printf("Update 1.rollno 2.name 3.marks\n");
  scanf("%d",&n);
  if(n==1||n==2||n==3)
      {
  	 while(fread(&v,sizeof(v),1,fp))
         	{   decrypt(&v);
                    if(v.rollno==choice)
			{
				if(n==1)
					{
						printf("Enter rollno to update:\n");
						scanf("%d",&v.rollno);
					}
				else if(n==2)
					{
						printf("Enter name to update:\n");
						scanf("%s",v.name);
					}
				else if(n==3)
					{
						printf("Enter marks to update:\n");
						scanf("%f",&v.mark);					
					}
                                else
					{
						printf("Invalid choice to update\n");
						fclose(fp);
						return;
					}
				fseek(fp,-1*sizeof(v),1);
                                encrypt(&v);
				fwrite(&v,sizeof(v),1,fp);
			}
		
	       }
    }
  else
     printf("Invalid choice for updating\n\n");
  fclose(fp);
}

void delete_record()
{
  FILE *fp,*fp1;
  struct student_database_encrypted v,*p,*temp;
  int choice,n1=0;
  fp=fopen("student_data_encrypt","r+");
  if(fp==NULL)
	{
		printf("ERROR: Data base doesnot exist\n");
		return;
	}
  printf("Enter rollno to delete record\n");
  scanf("%d",&choice);
  while(fread(&v,sizeof(v),1,fp))
	{
        	n1++;	
	} 
  rewind(fp);
  fp1=fopen("a.txt","w");
  while(fread(&v,sizeof(v),1,fp))
	{	
		decrypt(&v);
		if(v.rollno!=choice)// testing if not the record to delete and copying to another file
			{       encrypt(&v);
				fwrite(&v,sizeof(v),1,fp1);	
			}
	}
  fclose(fp);
  fclose(fp1);
  fp=fopen("student_data_encrypt","w");
  fp1=fopen("a.txt","r");
  while(fread(&v,sizeof(v),1,fp1))// copying file(with requested data deleted) data to main file
  	{      
                fwrite(&v,sizeof(v),1,fp);
	}
  fclose(fp);
  fclose(fp1);
  remove("a.txt");
  printf("Record deleted succesfully\n");
}

void sort_record()
{
  FILE *fp;
  struct student_database_encrypted *sp,*tp,v,temp; 
  int choice,i,j,n=0;
  printf("Enter choice:to sort by 1.Roll NO 2.Name 3.Marks\n");
  scanf("%d",&choice);
  fp=fopen("student_data_encrypt","r");
  while(fread(&v,sizeof(v),1,fp))
       n++;
  rewind(fp);  
  sp=malloc(n*sizeof(v));
  if(sp==NULL)
	{
		printf("Memory allocation Fault\n");
                return;
        }
   tp=sp;
   while(fread(&v,sizeof(v),1,fp))// copying whole data to dynamic memory
	{
                decrypt(&v);
		memcpy(sp,&v,sizeof(v));
		sp++;
	}
   fclose(fp);
   sp=tp;
   if(choice==1)// sort by rollno (bubble sort)
	{
		
                for(i=0;i<=n;i++)
			{
				for(j=0;j<n-i-1;j++)
					{	
					  if(((sp+j)->rollno)>((sp+j+1)->rollno))
						{
							temp.rollno=((sp+j)->rollno);
							((sp+j)->rollno)=((sp+j+1)->rollno);
							((sp+j+1)->rollno)=temp.rollno;	
							
							temp.mark=(sp+j)->mark;
							((sp+j)->mark)=((sp+j+1)->mark);
							((sp+j+1)->mark)=temp.mark;
			
							strcpy(temp.name,((sp+j)->name));
							strcpy(((sp+j)->name),((sp+j+1)->name));
 							strcpy(((sp+j+1)->name),temp.name);
						}
					}		
			}	
	}
   else if(choice==2)// sort by name (bubble sort)
	{
		
                for(i=0;i<=n;i++)
			{
				for(j=0;j<n-i-1;j++)
					{	
					  if(strcmp((sp+j)->name,(sp+j+1)->name)>0)
						{
							temp.rollno=(sp+j)->rollno;
							(sp+j)->rollno=(sp+j+1)->rollno;
							(sp+j+1)->rollno=temp.rollno;	
							
							temp.mark=(sp+j)->mark;
							(sp+j)->mark=(sp+j+1)->mark;
							(sp+j+1)->mark=temp.mark;
			
							strcpy(temp.name,(sp+j)->name);
							strcpy((sp+j)->name,(sp+j+1)->name);
 							strcpy((sp+j+1)->name,temp.name);
						}
					}		
			}	
	}
   else if(choice==3)// sort by marks (bubble sort)
	{
		
                for(i=0;i<=n;i++)
			{
				for(j=0;j<n-i-1;j++)
					{	
					  if((sp+j)->mark>(sp+j+1)->mark)
						{
							temp.rollno=(sp+j)->rollno;
							(sp+j)->rollno=(sp+j+1)->rollno;
							(sp+j+1)->rollno=temp.rollno;	
							
							temp.mark=(sp+j)->mark;
							(sp+j)->mark=(sp+j+1)->mark;
							(sp+j+1)->mark=temp.mark;
			
							strcpy(temp.name,(sp+j)->name);
							strcpy((sp+j)->name,(sp+j+1)->name);
 							strcpy((sp+j+1)->name,temp.name);
						}
					}		
			}	
	}
  else
      {
         printf("ERROR:Invalid choice to sort \n\n");
         return;
      }
  fp=fopen("student_data_encrypt","w");
  sp=tp;
  for(i=0;i<n;i++)  
	{
                encrypt(sp+i);
		fwrite((sp+i),sizeof(v),1,fp);
	}
  fclose(fp);
printf("Sorting succesfull\n\n");
}

void change_password()
{
  FILE *fp;
  int n1=0;
  char ch,pass[20],s[20];
  fp=fopen("password1.txt","r+");
  fread(&n1,sizeof(int),1,fp);
  if(n1==0) 
	{
           printf("Password does not exist: want to set(y/n)");
           getchar();
           scanf("%c",&ch);
           printf("\n\n");
           if(ch=='y')
              {
		  printf("Enter New password:(max 20 characters)");
      	          scanf("%s",pass);
      		  fwrite(pass,sizeof(pass),1,fp);
      		  rewind(fp);
		  n1=1;
		  fwrite(&n1,sizeof(int),1,fp);
      		  printf("password crated succesfully\n");
		  fclose(fp);
                  return;
	      }
           else
              {
                printf("password not changed\n\n");
                fclose(fp);
                 return;
              }
        }
 else if(n1==1)      
     {
          printf("Enter Existing password:\n");
          scanf("%s",pass);
          fread(s,sizeof(s),1,fp);
          if(strcmp(pass,s)==0)
             {
                   printf("Enter new password:\n");
                   scanf("%s",pass);
                   rewind(fp); 
                   n1=1;
                   fwrite(&n1,sizeof(int),1,fp);
                   fwrite(pass,sizeof(pass),1,fp);
                   printf("password changed succesfully\n");
                   fclose(fp);
                   return;
             }
           else
             {
                   printf("Password mismatch\n");
                   return;
             }
     }  
}


void encrypt(struct student_database_encrypted *p)
{ 
  char s[20];
  int i=0,r;
  float m;
  strcpy(s,p->name);
  r=p->rollno;
  m=p->mark;
  while(s[i])
     {
          if(i%2==0)
              s[i]+=2*i;
          else
              s[i]-=2*i;
          i++;
     }
 strcpy(p->name,s);
 p->rollno=r+i;
 p->mark=m-i; 
}

void decrypt(struct student_database_encrypted *p)
{
  char s[20];
  int i=0,r;
  float m;
  strcpy(s,p->name);
  r=p->rollno;
  m=p->mark;
  while(s[i])
     {
          if(i%2==0)
              s[i]-=2*i;
          else
              s[i]+=2*i;
          i++;
     }
 strcpy(p->name,s);
 p->rollno=r-i;
 p->mark=m+i;
}




